#make re
rm libftprintf.a
cp ../libftprintf.a .
make
