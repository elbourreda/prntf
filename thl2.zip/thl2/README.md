# Thala tester made by Kirwa for 1337 students
```
1-> clone the rep
```
```
2-> mv your libftprintf.a into folder that you clone
```
```

3-> make
```
4-> [click here to check difference](https://codebeautify.org/file-diff)
```
5-> put the SYSOUT and USEROUT
```
```
6-> compare the files
```
```
7-> and "thala"
```

# Thank you for your clone
